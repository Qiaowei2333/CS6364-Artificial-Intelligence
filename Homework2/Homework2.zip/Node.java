
public class Node {
	int Number;
	String Name;
	int SDdistance;
}
